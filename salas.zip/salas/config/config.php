<?php

	# Producción
    define('SALAS_COMP_DB_HOST', '127.0.0.1');
    define('SALAS_COMP_DB_PORT', '5432');
    define('SALAS_COMP_DB_NAME', 'salas');
    define('SALAS_COMP_DB_USER_NAME', 'postgres');
    define('SALAS_COMP_DB_USER_PASS', '123456');
    
?>
